local config = ngx.shared.config
local ip = ngx.req.get_uri_args().ip

if ip == nil or ip == ngx.null then
    ip = "192.168.0.55:8080"
end

config:set("mvw_upstream", ip);

ngx.say(ip .. ":ok")