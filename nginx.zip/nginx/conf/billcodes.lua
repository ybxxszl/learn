local json = require("cjson")
local bcpUtil= require("vis.visUtil")
local instance = bcpUtil.getRedisCon()
local count =json.decode(ngx.req.get_uri_args().count)
--通过每秒数据自增获取单位秒内的自增值
local retcodes = {}
for i=1,tonumber(count) do
	local time = os.date("%y%m%d%H%M%S");
	local incrkey = "bcpbillcode"..time;
	instance:setnx(incrkey, 0);
	instance:expire(incrkey,1);
	instance:incr(incrkey);
	local billcode = instance:get(incrkey);
	retcodes[i] = time..string.format("%03d",billcode)
end 
instance:close();
--生成单据号 e.g 14122018200801
ngx.say(json.encode(retcodes));
