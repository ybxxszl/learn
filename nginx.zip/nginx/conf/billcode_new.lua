 require "resty.core"
--通过每秒数据自增获取单位秒内的自增值
local config = ngx.shared.config
local incrkey = os.date("%y%m%d%H%M%S");
local billcode, err = config:incr(incrkey, 1, 0, 1);
--生成单据号 e.g 2014122018200801
ngx.say(incrkey..string.format("%02d",billcode));