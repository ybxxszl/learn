local config = ngx.shared.config
local mvw_upstream = config:get("mvw_upstream")

if mvw_upstream == nil or mvw_upstream == ngx.null then
    mvw_upstream = "192.168.0.55:8080"
end

ngx.log(ngx.INFO, "mvw_upstream="..mvw_upstream)

return mvw_upstream